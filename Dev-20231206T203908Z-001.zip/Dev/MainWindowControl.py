from PyQt5.QtWidgets import  *
from PyQt5.QtCore import pyqtSlot,pyqtSignal,Qt,QDateTime,QTimer,QMimeData
from PyQt5.QtWidgets import QMainWindow
import _thread
from  MainWindow import Ui_MainWindow
# 检测
import os
from GXUtils.ToolBox import getTimeCodeString2
from GXUtils.Configure import Configure
from GXUtils.CamreaHelper.CamreaHelper import CamreaHelper
from GXUtils.GuiWidget.GuiCamreaWidget.CamreaWidgetControl import CamreaWidget
from GXUtils.yolo.yolov5.Yolov5ObjectDetection import Yolov5ObjectDetection
import cv2
import PyQt5
from PyQt5 import QtWidgets, QtCore
class MainWindow(QMainWindow, Ui_MainWindow):


    textEditSignal = QtCore.pyqtSignal(PyQt5.QtWidgets.QTextEdit, str)
    DeviceDragWidgetSignal = QtCore.pyqtSignal(str, str,bool) #设备添加图标信号
    WarningInfoSignal = QtCore.pyqtSignal(str)
    """
    槽函数
    """
    def __init__(self, parent=None):
        """
        Constructor

        @param parent reference to the parent widget
        @type QWidget
        """
        #self.parent().show()
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.PamInit()
        self.CreateTask()
        # Initialize Object Detection
    def CreateTask(self):
        # 开始一个新的线程来执行doDectorProcess函数
        _thread.start_new_thread(self.doDectorProcess, ())
        pass
    def doDectorProcess(self):
        while(True):
            Frame = self.CamreaObj.getFrame()
            pre_list = self.ObjDetector.detect(Frame)
            for pre in pre_list:
                Name = pre['class_name']  # 获取类别名称
                (stx, sty), (ex, ey) = (int(pre['xyxy'][0]), int(pre['xyxy'][1])), (
                int(pre['xyxy'][2]), int(pre['xyxy'][3]))  # 获取目标框的起始坐标和结束坐标
                cv2.putText(Frame, Name, (stx, sty - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)  # 在帧上添加目标类别名称
                cv2.rectangle(Frame, (stx, sty), (ex, ey), (255, 0, 255), 2)  # 在帧上绘制目标框
            self.CamreaDisplayObj.showFrame(Frame)
            '''
            这部分代码中，首先通过self.CamreaObj调用getFrame()
            方法来获取摄像头捕获的一帧图像，并将其赋值给变量Frame。
            然后通过self.CamreaDisplayObj调用showFrame()方法，
            将获取的图像数据作为参数传递给showFrame()方法，
            用于在界面上展示摄像头捕获的图像。这段代码的作用是实时显示摄像头捕获的图像。
            '''
    def loadSystemCfg(self):
        self.setWindowTitle("crack detection")
    def PamInit(self):
        #加载配置文件
        self.loadSystemCfg()

        self.ObjDetector = Yolov5ObjectDetection('GXUtils/yolo/yolov5/onnx_model/best.pt')

        self.CamreaDisplayObj = CamreaWidget()
        self.CamreaDisplayObj.showDefFrame()
        self.gridLayout.addWidget(self.CamreaDisplayObj)
        '''
        `这部分代码是在一个类的方法中创建一个新的`CamreaWidget`实例，
        并将其赋值给`self.CamreaDisplayObj`变量。然后调用`showDefFrame`方法，
        该方法接受一个元组作为参数，用于设置默认的显示尺寸为（1920，1080）。
        最后，将`self.CamreaDisplayObj`添加到`gridLayout`中。
        这样做可能是为了将`CamreaWidget`的显示界面嵌入到一个包含其他组件的布局中。
        '''

        # 创建一个相机对象，并设置相机信息为(1920, 1080)
        self.CamreaObj = CamreaHelper(CamreaInfo=(1280, 768))
        # 打开编号为0的相机
        self.CamreaObj.open(1)


        pass
    @pyqtSlot()
    def on_pushButton_clicked(self):

        pass

    @pyqtSlot()
    def on_pushButton_7_clicked(self):
        pass
        #

