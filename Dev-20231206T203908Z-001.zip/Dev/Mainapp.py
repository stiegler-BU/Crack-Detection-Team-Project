from PyQt5.QtCore import *
from PyQt5.QtWidgets import  *
from PyQt5 import *
from PyQt5.QtGui import *
from PyQt5.QtCore import pyqtSlot,pyqtSignal
from PyQt5.QtWidgets import QMainWindow
from PyQt5 import QtCore,QtGui,QtWidgets
import faulthandler
faulthandler.enable()
from threading import Semaphore
import _thread
from MainWindow import Ui_MainWindow
import sys
import numpy as np
import time
import os
from MainWindowControl import MainWindow
class WidgetController:
    def __init__(self):
        self.MainWidget = MainWindow()  #登录页面
        pass
    def showLoginWidget(self):
        self.MainWidget.show()
if __name__ == "__main__":

    app = QtWidgets.QApplication(sys.argv)
    Widgetcontroller =  WidgetController()
    Widgetcontroller.showLoginWidget() #先显示登录页面
    sys.exit(app.exec_())
