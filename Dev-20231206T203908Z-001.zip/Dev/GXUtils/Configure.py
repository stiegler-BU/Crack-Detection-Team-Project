# -*- coding: utf-8 -*-
import configparser
import os
class Configure:
    def __init__(self,filename):
        self.filename = filename
        self.config = configparser.ConfigParser()
        if(False == os.path.exists(filename)):
            fd = open(filename,'w+', encoding='utf-8')
            fd.close()
        self.config.read(filename, encoding='utf-8')
        pass
    def set(self,section,key,value):
        list = self.config.sections()
        if(section not in list):
            self.config.add_section(section)
        self.config.set(section,key,value)
        fd = open(self.filename,'w+')
        self.config.write(fd)
        fd.close()
    def get(self,section,key):
        list = self.config.sections()
        if(section not in list):
            return []
        return self.config.get(section,key)


