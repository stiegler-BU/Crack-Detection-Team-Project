#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# exit interrupt lib
try:
	import locale
	locale.setlocale(locale.LC_CTYPE,'chinese')
except:
	pass
import os
import platform
import re
import socket
import subprocess
import time
from datetime import datetime
import sys
import psutil


#获取当前的时间
def getNowTimeString():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
def getNowTimeString2():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
#获取时间
def getTimeCodeString():
    return time.strftime("%Y%m%d%H%M%S", time.localtime())
def getTimeCodeString2():
    return time.strftime("%Y年%m月%d日_%H时%M分%S秒", time.localtime())
def get13BitTick():
    return int(round(time.time() * 1000))
#获取两个时间的时间差
def getTimeDifference(date1,date2):
    date1 = datetime.strptime(date1, "%Y-%m-%d %H:%M:%S")
    date2 = datetime.strptime(date2, "%Y-%m-%d %H:%M:%S")
    duration = date1 - date2
    day = duration.days
    hour = duration.seconds / 3600
    return day,hour
def GetLocalIPByPrefix(prefix):
    localIP = ''
    for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
        if ip.startswith(prefix):
            localIP = ip

    return localIP
def getCpuTemp():
    p = subprocess.Popen('cat /sys/class/thermal/thermal_zone0/temp', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        Lines = p.stdout.readlines()
        if (len(Lines[0]) > 0):
            temp = round(float(Lines[0].decode('utf-8')) / 1000,1)
            return temp
        else:
            return 0
    except:
        return 0
def getCpuUse():
    return psutil.cpu_percent()
def getMemInfo():
    mem = psutil.virtual_memory()
    memtotal =  int(float(mem.total) / 1024 / 1024)
    memuse =  int(float(mem.used) / 1024 / 1024)
    memfree = int(float(mem.free) / 1024 / 1024)
    return memtotal,memuse,memfree
def getRandCode():
    import random
    checkcode = ''
    for i in range(4):
        a = random.randint(0, 9)  # 生成一个0～9随机数
        b = str(a)  # 把生成的随机数转变成str字符串类型，以便下一行进行拼接操作
        checkcode = checkcode + b
    return checkcode
def getLocalIpList():
    if platform.system().lower() == 'windows':
        return socket.gethostbyname_ex(socket.gethostname())[2]
    elif platform.system().lower() == 'linux':
        AllNetDeviceList = []


        #树莓派linux下使用ifconfig命令获取所有的ip地址
        p = subprocess.Popen('ifconfig', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        Lines = p.stdout.readlines()
        Count = 0
        #print(Lines)
        for line in Lines:
            try:
                Ip = re.search(r"(([01]?\d?\d|2[0-4]\d|25[0-5]\d)\.){3}([01]?\d?\d|2[0-4]\d|25[0-5]\d)", str(line))[0]
                if(Ip != '127.0.0.1' and Ip.split('.')[-1] != '1'):
                    # 取出上一行的网络名
                    DeviceIpList = {}
                    NetName = str(str(Lines[Count - 1]).split(':')[0][2:])
                    #测试中发现有可能无法获取MAC地址
                    try:
                        MacAddr = str(str(Lines[Count + 3]))
                        MacAddr = re.findall(re.compile(r'(?:[0-9a-fA-F]:?){12}'),MacAddr)[0]
                    except:
                        MacAddr = ''
                    DeviceIpList['NetName'] = NetName

                    DeviceIpList['ip'] = Ip
                    DeviceIpList['Mac']  = MacAddr
                    AllNetDeviceList.append(DeviceIpList)
            except:
                pass
            Count += 1
        return AllNetDeviceList
def checkCamreaStatus():
    #检查摄像头的状态
    p = subprocess.Popen('ls /dev/video0', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        Lines = p.stdout.readlines()
        if(str(Lines[0]).index('/dev/video0') > 0):
            return '/dev/video0'
        else:
            return 'null'
    except:
        return 'null'
def getUUID():
    uuid = 'null'
    #获取设备的UUID，一般树莓派下我们就使用SerialCode,ubuntu下使用uuid
    p = subprocess.Popen('sudo blkid', shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    Lines = p.stdout.readlines()
    for line in Lines:
        line = str(line)
        if(line.find("/dev/sda1") > 0):
            startcut = line.find('UUID="') + 6
            endcut = startcut + 36
            uuid = str(line[startcut:endcut])
    return uuid
def getPiDeviceInfo():
    #获取树莓派的设备信息
    p = subprocess.Popen('cat  /proc/cpuinfo', shell=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    Lines = p.stdout.readlines()
    try:
        SerialCode = str(str(Lines[-2]).split(':')[1][1:-3])
        Model = str(str(Lines[-1]).split(':')[1][1:-3])
    except:
        SerialCode = getUUID()
        Model = 'Ubuntu'
    return SerialCode,Model
def IpToBoardCastAddr(Ip):
    localip = Ip.split('.')
    localip = localip[0] + '.' + localip[1] + '.' + localip[2] + '.255'
    return localip
#比较两个列表，判断列表中的值是否一样
def CmpList():
    pass
def getCurDir():
    cur_dir = os.path.dirname(os.path.abspath(__file__))  # 上级目录
    return cur_dir
def getPlatform():
    if sys.platform.startswith('win'):
        return 'windows'
    elif sys.platform.startswith('darwin'):
        return 'macos'
    elif sys.platform.startswith('linux'):
        return 'linux'
    else:
        return 'other'
getCpuTemp()