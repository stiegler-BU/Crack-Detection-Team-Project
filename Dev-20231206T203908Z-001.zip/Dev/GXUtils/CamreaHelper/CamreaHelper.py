#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
实现摄像头的读取功能
实现摄像头的录制功能
'''
import _thread
import queue
import time

import cv2
from cv2 import getTickCount, getTickFrequency

debugflg = 0

from GXUtils.Logger import Logger
from GXUtils.ToolBox import getCurDir
from GXUtils.ToolBox import getNowTimeString2

from PyQt5.QtCore import QObject
from PyQt5.QtWidgets import *
import threading
from PyQt5 import QtCore
'''
参考文档:
https://blog.csdn.net/LaoYuanPython/article/details/115716366
'''

class CamreaHelper(QObject):

    signal_VideRecdTimeout = QtCore.pyqtSignal(int, str) #视频录制结束信号,传递录制帧数和录制的名称

    def __init__(self,CamreaInfo = (0,0),CamreaSource = 0,debugflg = 0,takePhotoMode = False):
        #2023.04.01 增加拍照模式，拍照模式应该是实时读取视频，只有在按下拍照时拍摄一直图片

        super(CamreaHelper, self).__init__()
        self.log = Logger().getlog(__name__)
        self.SrcImageQueue = queue.Queue(10)  # 原始图像数据队列
        self.VideoRecdQueue = queue.Queue(100)# 视频录制队列
        self.debugflg = debugflg
        self.CamreaInfo  = CamreaInfo #摄像头信息
        self.fpsCtl = 30 #帧率控制
        self.RecdFpg = 30
        self.takePhotoMode = takePhotoMode #拍照模式
        self.takePhotoFlg = False #拍照标志
        self.CamreaSource = CamreaSource #摄像头源头，默认第一个摄像头
        self.RecdVideoStu = False #视频录制状态
        self.RecdVideoStop = False
        self.ProcessStu = False
        self.ModuleStu = 0#模块的状态， 0 空闲状态  1 打开视频状态 2 打开摄像头转台 3 打开图片状态
        self.RecdFreamCount = 0 #录制帧数
        self.RecdVideoFileName = '' #视频录制时的文件名称
        self.VideoOutStream = None #视频输出流
        self.Capture = None
        self.VideoPuseFlg = False
        self.RecdVideoPushFlg =False #视频录制暂停
        self.RecdVideoSize = (int(self.CamreaInfo[0]), int(self.CamreaInfo[1])) #摄像头录制时的分辨率
        self.SupperCamreaInfo = {(640,480),(1024,768),(1920,1080)}
        self.camreanum = self.GetCamreaNumber()
        pass
    def GetCamreaNumber(self):
        cnt = 0
        for device in range(0, 10):
            stream = cv2.VideoCapture(device)
            grabbed = stream.grab()
            stream.release()
            if not grabbed:
                break
            cnt = cnt + 1
        return cnt

    def RightMenuClick(self,obj,pos):
        #print(obj,pos)
        #print(self.camreanum)
        menu = QMenu()  # 实例化菜单
        item1 = menu.addMenu(u"摄像头输入")
        subitem1 = item1.addMenu(u'摄像头选择')
        groupcam = list()
        if(self.camreanum > 0):
            for index in range(0,self.camreanum):
                groupcam.append(subitem1.addAction("摄像头-"+ str(index)))
        else:
             item = subitem1.addAction('未检测到摄像头')
        subitem2 = item1.addMenu(u'摄像头分辨率')

        groupRl = list()

        for caminfo in self.SupperCamreaInfo:
            info = str(caminfo[0])  + '*' +  str(caminfo[1])
            groupRl.append(subitem2.addAction(info))

        action = menu.exec_(obj.mapToGlobal(pos))
        if(action in groupcam):
            index = int(action.text().split('-')[1])
            self.open(index)
        if(action in groupRl):
            width,height = action.text().split('*')
            if(self.CamreaInfo !=  (int(width),int(height))):
                self.CamreaInfo = (int(width),int(height))
                self.log.info("开始设置相机工作参数")
                self.set()
                self.log.info("开始设置相机工作参数设置完成")
    #开始录制视频，指定视频录制的名称
    def startVideoRecd(self,VideoName,RecdTime = -1):
        if(self.RecdVideoStu):
            self.log.info('视频已经在录制状态')
            return False
        if(len(VideoName) == 0):
            self.log.info('视频文件名不存在')
            return False
        self.RecdVideoFileName = VideoName #指定录制名称
        self.RecdFreamCount = 0 #录制帧计数
        self.RecdTime = RecdTime #录制时常
        self.RecdVideoSize = (int(self.CamreaInfo[0]), int(self.CamreaInfo[1]))
        self.RecdStartTime = time.time()
        self.RecdVideoStop = False
        self.RecdVideoStu = True #开始录制
        if(RecdTime > 0):
            threading.Timer(RecdTime, self.stopVideRecd).start() #固定事件停止录制
        pass
    #对外提供帧获取接口
    def getFrame(self):
        return self.SrcImageQueue.get()
    #判断摄像头是否处于录制状态
    def isVideoRecd(self):
        return self.RecdVideoStu
    #获取视频录制时的文件路径和名称
    def lastRecdFileName(self):
        return self.RecdVideoFileName
    #停止录像
    def stopVideRecd(self):
        #停止录制
        self.RecdVideoStu = False
        self.RecdVideoStop = True
    #打开一个源设备
    def open(self,CamreaSource = 0):
        self.CamreaSource = CamreaSource
        self.log.info("输入源信息" + str(CamreaSource))
        if(self.ModuleStu > 0):
            #模块非空闲状态，需要先让模块进入空闲状态
            self.log.info('摄像头处于开启状态，即将进行关闭')
            self.close()
            #等待任务完全退出
            time.sleep(1)
        _thread.start_new_thread(self.CamreaRecdProcess, ())  # 图像采集线程
        _thread.start_new_thread(self.VideoRecdProcess,()) #视频录制线程
    def VideoRecdProcess(self):
        RecdVideoSize = (int(self.CamreaInfo[0]), int(self.CamreaInfo[1]))
        VideoFourcc = cv2.VideoWriter_fourcc(*'MJPG')  # 视频录制相关
        while(True):
            stop,frame = self.VideoRecdQueue.get()
            if(stop):
                if (self.VideoOutStream != None and self.VideoOutStream.isOpened()):
                    self.VideoOutStream.release()  # 释放录制，
                    self.log.info("视频录制结束,帧数:" + str(self.RecdFreamCount))
                    self.signal_VideRecdTimeout.emit(self.RecdFreamCount, self.RecdVideoFileName)
                continue
            if (self.RecdFreamCount == 0):
                # 第一帧，是开始帧，需要重置路径
                self.log.info("开始录制视频：" + self.RecdVideoFileName+" 帧率:"+ str(int(self.RecdFpg)))
                if(self.RecdFpg > 200):
                    self.RecdFpg = 200
                if(self.RecdFpg == 0):
                    self.RecdFpg = 20
                RecdVideoSize = (int(self.CamreaInfo[0]), int(self.CamreaInfo[1]))
                self.VideoOutStream = cv2.VideoWriter(self.RecdVideoFileName, VideoFourcc, 25, RecdVideoSize)
            self.VideoOutStream.write(frame)  # 写入帧信息
            self.RecdFreamCount += 1
    def set(self):
        try:
            if(self.Capture != None):
                if(self.CamreaInfo[0] != 0 and self.CamreaInfo[1] != 0):
                    # 设置捕获画面的宽度为摄像头信息中索引为0的值
                    self.Capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.CamreaInfo[0])
                    # 设置捕获画面的高度为摄像头信息中索引为1的值
                    self.Capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.CamreaInfo[1])
                    self.log.info("设置相机工作参数" + str(self.CamreaInfo[0]) + '*' + str(self.CamreaInfo[1]))
                else:
                    self.CamreaInfo = (640,480)
                    #摄像头默认是这个工作参数了
                    self.CamreaInfo[1] =  self.Capture.get(cv2.CAP_PROP_FRAME_HEIGHT)
                    self.CamreaInfo[0] = self.Capture.get(cv2.CAP_PROP_FRAME_WIDTH)
                self.Capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))  # 这个很关键,这个可以同时使用多个摄像头,但是这个非常耗时
                #if(self.Capture.get(cv2.CAP_PROP_FPS) != 30):
                #    self.Capture.set(cv2.CAP_PROP_FPS,30)
            pass
        except:
            self.log.info('相机工作参数设置失败')
    def takePhoto(self):
        if(self.ProcessStu):
            # while(True):
            #     try:
            #         img = self.SrcImageQueue.get_nowait()
            #     except queue.Empty:
            #         break
            # self.takePhotoFlg = True
            return self.SrcImageQueue.get(),True
            #等待拍色完成
        else:
            print("摄像头打开失败，无法进行拍照")
            return None,False

    def VideoRecdPuse(self):
        self.RecdVideoPushFlg = True
    def VideoRecdContinue(self):
        self.RecdVideoPushFlg = False
    def puse(self):
        self.VideoPuseFlg = True
    def continues(self):
        self.VideoPuseFlg = False
    def close(self):
        #关闭摄像头，
        #1、确认摄像头模块是否已经在工作，
        if(self.ModuleStu > 0):
            #先删除摄像头任务
            self.ProcessStu = False
            #等待摄像头释放成
            pass
        pass
    def isWork(self):
        if(self.ModuleStu > 0):
            return True
        return False
    def isOpened(self):
        return self.ProcessStu
    def CamreaRecdProcess(self):
        self.log.info("摄像头线程运行成功")
        self.VideoRecdFlg = False

        #打开摄像头，读取摄像头数据，并送入队列
        if(self.debugflg == 0):
            #cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)  # 打开摄像头
            self.Capture = cv2.VideoCapture(self.CamreaSource,cv2.CAP_DSHOW)  # 打开摄像头,加速摄像头打开
            #cv2.VideoCapture('/dev/video0')
            #cv2.VideoCapture('test.mp4')
            status = self.Capture.isOpened()
            if(status):
                self.log.info("相机打开成功")
            else:
                self.log.info("相机打开失败")
            self.set()#配置相机某块工作参数
        else:
            self.log.info('图片输入模式')
            status = True
        count = 0
        self.ModuleStu = 1
        start = time.time()
        self.log.info('开始进行图像/摄像头读操作')
        #这里打开摄像头使用大概需要5秒时间，原因未知
        frameCount = 0
        self.ProcessStu = status
        while(self.ProcessStu):
            if(self.VideoPuseFlg):
                time.sleep(0.01)
                continue
            start = time.time()
            tick = getTickCount()
            if(self.debugflg == 0):
                ret, img = self.Capture.read()
            else:
                ret = True
                img = cv2.imread(getCurDir() + '/Image/2.png')
                img = cv2.resize(img,(self.CamreaInfo[0],self.CamreaInfo[1]))
            if ret:
                #帧录制
                tick = (getTickCount() - tick) / getTickFrequency()
                fps = 1.0 / tick
                frameCount += 1
                img = cv2.putText(img,"fps:{0:02d}".format(int(fps))  + " "+ getNowTimeString2(),(20,30),cv2.FONT_HERSHEY_SIMPLEX,1,(255,255,255))
                self.RecdFpg = fps
                if(self.RecdVideoStu):
                    if(self.RecdVideoPushFlg == False):
                        self.RecdVideoStop = False
                        try:
                            self.VideoRecdQueue.put_nowait([False,img]) #将图像送入队列进行存储
                        except queue.Full:
                            pass
                if(self.RecdVideoStop == True):
                    #停止录制
                    self.RecdVideoStop = False
                    self.VideoRecdQueue.put([True, img])
                if(self.takePhotoMode):
                    #拍照模式下，只有在允许拍照时拍摄一直图片
                    if(self.takePhotoFlg):
                        self.takePhotoFlg = False
                        try:
                            pass
                            self.SrcImageQueue.put_nowait(img)
                        except queue.Full:
                            pass
                else:
                    try:
                        pass
                        self.SrcImageQueue.put_nowait(img)
                    except queue.Full:
                        pass
                time.sleep(0.025) #这里需要延时，如果不延时就回一直到队列中取，那么导致队列会等
        self.ModuleStu = 0
        self.log.info('相机处理线程退出成功')
        self.Capture.release()