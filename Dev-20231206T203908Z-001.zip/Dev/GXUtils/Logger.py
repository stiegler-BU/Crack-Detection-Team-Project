# -*- coding: utf-8 -*-
import logging
import os
import time

log_type = 1

class Logger():
    def __init__(self):
        self.path = os.path.dirname(__file__)
        pass
    def getlog(self,logger_name):
        """得到日志对象"""
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter('[ %(asctime)s ] - %(levelname)s - %(message)s')

        if not logger.handlers:
            # 用于输出至文件
            #判断Log文件夹村部存在
            if(not os.path.exists(self.path + '/../Log')):
                os.mkdir(self.path + '/../Log')
            log_file = os.path.join(self.path + "/../Log", "{}_log.txt".format(time.strftime("%Y_%m_%d", time.localtime())))
            file_log_handler = logging.FileHandler(log_file,encoding='utf-8')
            file_log_handler.setLevel(logging.DEBUG)
            file_log_handler.setFormatter(formatter)
            # logger绑定处理对象
            logger.addHandler(file_log_handler)

            ch = logging.StreamHandler()
            ch.setLevel(logging.DEBUG)
            ch.setFormatter(formatter)
            logger.addHandler(ch)
        return logger