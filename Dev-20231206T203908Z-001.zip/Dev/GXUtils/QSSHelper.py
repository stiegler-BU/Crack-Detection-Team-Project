from PyQt5.QtCore import QFile,QIODevice,QTextStream
class QSSHelper():
    def __init__(self):
        pass
    def loadQss(self,Obj,resource_path):
        # 打开资源文件
        stream = QFile(resource_path)
        # 以只读模式打开流
        stream.open(QIODevice.ReadOnly)
        # 从流中读取样式并设置给Obj
        Obj.setStyleSheet(QTextStream(stream).readAll())
